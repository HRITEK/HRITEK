
let ListofFavouriteMovie=document.querySelector(".ListofFavouriteMovie")
let wholeFavouriteList=JSON.parse(localStorage.getItem("favMovie"))
console.log(wholeFavouriteList)

wholeFavouriteList.forEach((movie)=>{

 let card=`<div class="cards">
<img class="cards__img" src=https://image.tmdb.org/t/p/original${movie?movie.poster_path:""}
/>


<div class="cards__overlay">


    <div class="card__title">${movie?movie.original_title:""}</div>
    <div class="card__runtime">
       ${movie?movie.release_date:""}
        <span class="card__rating">${movie?movie.vote_average:""}<i class="fas fa-star"></i></span>
    </div>
    <div class="card__description">${movie ? movie.overview.slice(0,118)+"..." : ""}</div>
</div>
</div>`

ListofFavouriteMovie.insertAdjacentHTML("beforeend",card)
})