const INTERVIEW = require("../models/interviewModel");
const STUDENT = require("../models/studentModel");







async function showEditStudentPage(req,res){

  

 try{
  const student = await STUDENT.findById(req.params.id);
  return res.render("editStudent", {
    title: "Edit Student",
    student_details: student,
  });
 }
   
  catch(err){
    return res.redirect("/");
  }




}









async function showStudentAddPage(req,res){
try{


  return res.render("addStudent", {
    title: "Add Student",
  });
}
catch(err){
  return res.redirect("/") 

}
}












  async function addStudent(req, res) {

try{
  const {
    name,
    email,
    college,
    batch,
    dsaScore,
    webScore,
    reactScore,
    placementStatus,
  } = req.body;

  let student= await STUDENT.findOne({ email: email })
    

   if (student) {
    // req.flash("error", "Student already exist!");
    return res.json({message:"student alrady exist"});  

    }


  let newcreated=await STUDENT.create({
      name,
      email,
      college,
      batch,
      dsaScore,
      webScore,
      reactScore,
      placementStatus,
    })

if(newcreated){
    // req.flash("error", "Student already exist!");
    return res.json({message:"student added succcesfull"}); 
}

 

}

catch(err){
console.log(err)
}
  
    
}




async function deleteStudent(req,res){
try{


let {studentId}=req.params

const student=await STUDENT.findById(studentId)

if(!student){
//     req.flash("error", "Couldn't find student");
    return res.json({message:"student couldnt find"});
}

console.log(student)
const interviewofStudent=student.interviews
console.log(interviewofStudent)

/// delete reference of student from companies in which this student is enrolled

if(interviewofStudent.length>0){
    for(let interview of interviewofStudent){

await INTERVIEW.findOneAndUpdate({company:interview.company},{

    $pull:{students:{student:studentId}}
})
}}

student.deleteOne();
// req.flash("success", "Student deleted!");
return res.json("student deleted succesfully");


}
catch(err){
console.log(err)
}


}



async function updateStudent(req,res){

try{

const {id}=req.params;
console.log(id)

const student=await STUDENT.findById(id)

const {
    name,
    college,
    batch,
    dsaScore,
    reactScore,
    webScore,
    placementStatus,
  } = req.body;

  student.name = name;
  student.college = college;
  student.batch = batch;
  student.dsaScore = dsaScore;
  student.reactScore = reactScore;
  student.webScore = webScore;
  student.placementStatus =placementStatus;

  student.save()
//   req.flash("success", "Student updated!");
  return res.redirect("/dashboard");




}

catch(err){
 
    
    console.log(err);
    return res.redirect("back");

}



}


module.exports = { showEditStudentPage,addStudent,deleteStudent,updateStudent,showStudentAddPage };
