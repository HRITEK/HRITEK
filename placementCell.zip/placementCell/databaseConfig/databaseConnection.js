const mongoose=require("mongoose")




 async function dbConnection(){
try{
await mongoose.connect("mongodb+srv://gurpreetsingh:Shalu%401999@cluster0.apn6ahn.mongodb.net/?retryWrites=true&w=majority")
console.log("connected to mongoDb")
}

catch(err){
    console.log(err)
}


}


module.exports=dbConnection