const express=require('express')
const { addInterview, addStudentToInterview, deAllocate, showInterviewPage } = require('../controllers/interviewController')

const interviewRoute=express.Router()


interviewRoute.get('/addinterview',showInterviewPage)


interviewRoute.post('/createinterview',addInterview)

interviewRoute.put('/enroll/:id',addStudentToInterview)

interviewRoute.delete('/delete/:studentId/:interviewId',deAllocate)




module.exports=interviewRoute


