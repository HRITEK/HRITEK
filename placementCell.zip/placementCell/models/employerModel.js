
const mongoose=require('mongoose')
const bcrypt = require('bcrypt');



let employerSchema=new mongoose.Schema({

name:{
type:String,
required:true
},
email:{
    type:String,
    required:true,
    unique:true
},
password:{
    type:String,
    required:true
}



})





employerSchema.pre('save',function(next){
let saltRound=10;
let user=this
let password=user.password


 bcrypt.hash(password,saltRound,function(err,hashed){

   user.password=hashed;

    next()
 })


})


employerSchema.methods.comparePassword=function(password,cb){


    let user=this;


bcrypt.compare(password,user.password,function(err,result){


if(result){
cb(null,result)
}
else{
    cb(err,false)
}





})

}



let EMPLOYERMODEL=mongoose.model("EMPLOYERMODEL",employerSchema)

module.exports=EMPLOYERMODEL



