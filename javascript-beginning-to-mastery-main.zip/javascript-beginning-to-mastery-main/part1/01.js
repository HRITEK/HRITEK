// console.log can print something on console 
console.log("hello world");