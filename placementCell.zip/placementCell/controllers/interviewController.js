



//creation of new interview 

const INTERVIEW = require("../models/interviewModel");
const STUDENT = require("../models/studentModel");


async function showInterviewPage(req,res){
try{


return res.render('addinterview',{
    title:"Schedule An Interview"
})

}
catch(err){
    return res.redirect('/')
}
}











async function addInterview(req,res){

try{
const {company,date}=req.body;

let interview=await INTERVIEW.create({
    company,
    date
})


if(interview){
    res.json({message:"interview added succesfully"})
}


}


catch(err){
    console.log(err);
}

}


//adding student in the interview


async function addStudentToInterview(req,res){

    try{
        const {id}=req.params
    const {email,result}=req.body


let interview=await INTERVIEW.findById(id)

if(interview){
 
let student=await STUDENT.findOne({email:email})

//preventing student from enrolling in the same company again
if(student){


let alreadyEnrolled=await INTERVIEW.findOne({
    students:{$elemMatch:{student:student._id}}
})


if(alreadyEnrolled){
    if(alreadyEnrolled.company===interview.company){
        // req.flash(
        //     "error",
        //     `${student.name} already enrolled in ${interview.company} interview!`
        //   );
          return res.json({message:"student already enroolled for this interview"});
    }
}


let studentObj={
    student:student.id,
    result:result
}


 //updating students field of interview by putting reference of newly enrolled student

await INTERVIEW.updateOne({
    $push:{students:studentObj}
})


    // updating interview of student

    let assignedInterview={
        company:interview.company,
        date:interview.date,
        result:result
    }

await STUDENT.updateOne({
    $push:{interviews:assignedInterview}
})

// req.flash(
// //     "success",
// //     `${student.name} enrolled in ${interview.company} interview!`
// //   );
  return res.json({message:"student enrolled succesfully"});
}

// req.flash("error", "Student not found!");
return res.json({message:"student couldny find"});

}

// req.flash("error", "interview not found!");
return res.json({message:"interview couldnt found"});
    




    }
  

catch(err){
console.log(err)
// req.flash("error", "Error in enrolling interview!");
}


}



// deallocating students from an interview


async function deAllocate(req,res){

    try{
        const {studentId,interviewId}=req.params

        // find the interview
        
        const interview=await INTERVIEW.findById(interviewId)
        
        if(interview){
         
            
            await INTERVIEW.findOneAndUpdate({_i:interviewId},{
                $pull:{students:{student:studentId}}
            })
        
        
        await STUDENT.findOneAndUpdate({_id:studentId},{
            $pull:{interviews:{comapany:interview.company}}
        })
        // req.flash(
        //     "success",
        //     `Successfully deallocated from ${interview.company} interview!`
        //   );
          return res.json({message:"`Successfully deallocated from interview!`"});
        }
        // req.flash("error", "Interview not found");
        return res.json("interview not found");
    }

catch(err){
    console.log(err)
}
}





module.exports={addInterview,addStudentToInterview,deAllocate,showInterviewPage}