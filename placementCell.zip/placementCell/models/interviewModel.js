
const mongoose=require('mongoose')



let interviewSchema=new mongoose.Schema(
    {
      company: {
        type: String,
        required: true,
      },
      date: {
        type: String,
        required: true,
      },
      students: [ // i want to populate students.student but here i  am getting eror
        {
          student: { //
            type: mongoose.Schema.Types.ObjectId,
            ref: "STUDENT",
          },
          result: {
            type: String,
            enum: ["Pass", "Fail", "Didn't Attempt", "On Hold"],
          },
        },
      ],
    },
    {
      timestamps: true,
    }
  );




let INTERVIEW=mongoose.model("INTERVIEW",interviewSchema)

module.exports=INTERVIEW

