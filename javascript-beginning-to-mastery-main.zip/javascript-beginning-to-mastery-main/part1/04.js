// let keyword 
// declare variable with let keyword 

let firstName = "harshit";
firstName = "Mohit";
console.log(firstName);


// block scope vs funtion scope (covered later in this video)