"use strict";
// intro to variables

// variables can store some information
// we can use that information later
// we can change that information later

// declare a variable 

var firstName = "Harshit";

// use a variable 
console.log(firstName);

// change value 

firstName = "Mohit";

console.log(firstName);
