const express=require('express')
const { addStudent, updateStudent, deleteStudent, showStudentAddPage, showEditStudentPage } = require('../controllers/studentController')

const studentRoute=express.Router()


studentRoute.get('/addstudent',showStudentAddPage)
studentRoute.get('/edit/:id',showEditStudentPage)



studentRoute.post('/createstudent',addStudent)
studentRoute.post('/update/:id',updateStudent)
studentRoute.delete('/delete/:studentId',deleteStudent)

 

module.exports=studentRoute



