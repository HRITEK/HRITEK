const EMPLOYERMODEL = require("../models/employerModel.js")
const jwt=require("jsonwebtoken");
const STUDENT = require("../models/studentModel.js");
const INTERVIEW = require("../models/interviewModel.js");

let token;


const showSignInPage=(req,res)=>{
    return res.render("employerSignIn", {
        title: "Placement cell | Sign In",
      });
}

const showSignUpPage=(req,res)=>{
    return res.render("employerSignUp", {
        title: "Placement cell | Sign Up",
      });
}


const signin=async(req,res)=>{

    // if(req.isAuthenticated()){
    //     return res.json({message:'already logged in'})
    // }


 const {email}=req.body


 let user=await EMPLOYERMODEL.findOne({email:email})

if(user){
user.comparePassword(req.body.password,(err,result)=>{
if(result){
    token=jwt.sign(user.toJSON(),'codeial',{expiresIn:'1000000s'})
     res.cookie("access_token",token)
    return res.redirect('/v1/dashboard')
}
else
{
    res.json("user not found")

}})


 }



}

async function signup(req,res){

  try{


        const {name,email,password}=req.body
console.log(name,email,password)

       const employer= await EMPLOYERMODEL.create({
            name:name,
            email:email,
            password:password
        })


  return  res.redirect('/v1/')
}
catch(err){
    console.log(err)
}


    }




function verifying(req,res){

if(req.isAuthenticated()){
    
    return res.json({message:"our passport authentication is working",
user:req.user})
}




}


function logout(req,res){

   req.logout()

   return res.redirect("/")


}
async function showDashboardPage(req,res){

    try{
    
    
        let students = await STUDENT.find({}).populate("interviews");
        console.log(students)
       let interviews= await INTERVIEW.find({}).populate('students.student')// this is not working
 






        return res.render('dashboardPage', {
            title: "Dashboard",
            all_students: students,
            all_interviews: interviews,
          });
        }
        catch(err){
           
            return res.json("not working")
        }
    
    }




    
    
    



module.exports={showDashboardPage,signin,signup,verifying,logout,showSignInPage,showSignUpPage}